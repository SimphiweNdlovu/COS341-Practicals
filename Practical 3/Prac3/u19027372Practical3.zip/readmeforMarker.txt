To run the Prac3.jar file on ubuntu System run the following command on the terminal
"java -jar Prac3.jar"

Im using my Practical 2.
use the input.txt to test 

*Node: scopeID procedure is the node ID of the parent*


output is on symbolTable.html
*Note: it will not run when cliked.*