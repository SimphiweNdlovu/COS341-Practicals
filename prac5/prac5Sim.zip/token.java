
class token
{
    int id; //(position of the token in the stream).
    String _class; //  (for example: number, or keyword) 
    String contents; // token-type

}