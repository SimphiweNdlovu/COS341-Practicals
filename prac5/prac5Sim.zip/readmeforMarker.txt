To run the prac5.jar file on ubuntu System run the following command on the terminal
"java -jar prac5.jar"

Im using my Practical 2.
use the input.txt to test 

*Node: scopeID procedure is the node ID of the parent*


output is on basicCode.txt
*Note: it will not run when cliked.*
