To run the practical2.jar file on ubuntu System run the following command on the terminal
"java -jar practical2.jar"

use the input.txt to test 



*Note: it will not run when cliked.